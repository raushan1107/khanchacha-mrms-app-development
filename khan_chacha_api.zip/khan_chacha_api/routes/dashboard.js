const express = require('express');
const router = express.Router();
const pool = require('../db/connection');

router.get('/counts', async (req, res) => {
  try {
    let result;

    if (req.query.outlet_id) {
      result = await pool.query(
        `SELECT status, COUNT(*)::int AS total
         FROM maintenance_requests
         WHERE outlet_id = $1
         GROUP BY status`,
        [req.query.outlet_id],
      );
    } else {
      result = await pool.query(
        `SELECT status, COUNT(*)::int AS total
         FROM maintenance_requests
         GROUP BY status`,
      );
    }

    const counts = { Open: 0, Pending: 0, Closed: 0 };
    result.rows.forEach(row => { counts[row.status] = row.total; });

    res.json(counts);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
