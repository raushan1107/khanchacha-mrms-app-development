const express = require('express');
const router = express.Router();
const pool = require('../db/connection');

router.post('/login', async (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password required' });
  }

  try {
    const result = await pool.query(
      `SELECT u.id, u.name, u.username, u.password, u.role, u.outlet_id, o.name AS outlet_name
       FROM users u
       JOIN outlets o ON u.outlet_id = o.id
       WHERE u.username = $1`,
      [username],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    const row = result.rows[0];

    // TODO: replace plain text comparison with bcrypt.compare() in production
    if (row.password !== password) {
      return res.status(401).json({ error: 'Invalid password' });
    }

    res.status(200).json({
      id: row.id,
      name: row.name,
      username: row.username,
      role: row.role,
      outletId: row.outlet_id,
      outletName: row.outlet_name,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
