const express = require('express');
const router = express.Router();
const pool = require('../db/connection');

const BASE_QUERY = `
  SELECT r.*, o.name AS outlet_name, o.address AS outlet_address,
         u.name AS manager_name
  FROM maintenance_requests r
  JOIN outlets o ON r.outlet_id = o.id
  JOIN users   u ON r.raised_by = u.id
`;

router.get('/', async (req, res) => {
  try {
    let query = BASE_QUERY;
    const params = [];

    if (req.query.outlet_id) {
      query += ' WHERE r.outlet_id = $1';
      params.push(req.query.outlet_id);
    }

    query += ' ORDER BY r.request_date DESC';

    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const query = BASE_QUERY + ' WHERE r.id = $1 ORDER BY r.request_date DESC';
    const result = await pool.query(query, [req.params.id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Request not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/', async (req, res) => {
  const {
    id, product_name, product_id, category, status, request_date,
    description, image_path, outlet_id, raised_by,
  } = req.body;

  const required = { id, product_name, product_id, category, outlet_id, raised_by };
  for (const [field, value] of Object.entries(required)) {
    if (value === undefined || value === null || value === '') {
      return res.status(400).json({ error: `Missing required field: ${field}` });
    }
  }

  try {
    await pool.query(
      `INSERT INTO maintenance_requests
         (id, product_name, product_id, category, status, request_date,
          description, image_path, outlet_id, raised_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
      [id, product_name, product_id, category, status, request_date,
       description, image_path, outlet_id, raised_by],
    );

    const result = await pool.query(
      BASE_QUERY + ' WHERE r.id = $1 ORDER BY r.request_date DESC',
      [id],
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.put('/:id', async (req, res) => {
  const {
    product_name, product_id, category, status, request_date,
    description, image_path,
  } = req.body;

  try {
    const result = await pool.query(
      `UPDATE maintenance_requests
       SET product_name=$1, product_id=$2, category=$3,
           status=$4, request_date=$5, description=$6, image_path=$7, updated_at=NOW()
       WHERE id = $8`,
      [product_name, product_id, category, status, request_date,
       description, image_path, req.params.id],
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Request not found' });
    }

    const updated = await pool.query(
      BASE_QUERY + ' WHERE r.id = $1 ORDER BY r.request_date DESC',
      [req.params.id],
    );

    res.json(updated.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.patch('/:id/status', async (req, res) => {
  const { status, history_entry } = req.body;

  try {
    const result = await pool.query(
      `UPDATE maintenance_requests
       SET status = $1,
           status_history = status_history || $2::jsonb,
           updated_at = NOW()
       WHERE id = $3`,
      [status, history_entry, req.params.id],
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Request not found' });
    }

    const updated = await pool.query(
      BASE_QUERY + ' WHERE r.id = $1 ORDER BY r.request_date DESC',
      [req.params.id],
    );

    res.json(updated.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const result = await pool.query(
      'DELETE FROM maintenance_requests WHERE id = $1',
      [req.params.id],
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Request not found' });
    }

    res.status(200).json({ message: 'Deleted successfully', id: req.params.id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
