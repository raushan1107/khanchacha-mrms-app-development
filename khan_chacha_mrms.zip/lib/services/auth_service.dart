import '../models/user_account.dart';
import 'api_service.dart';

class AuthService {
  AuthService._internal();

  static final AuthService _instance = AuthService._internal();

  factory AuthService() => _instance;

  UserAccount? currentUser;

  Future<UserAccount?> login(String username, String password) async {
    try {
      final user = await ApiService().loginUser(username, password);
      currentUser = user;
      return user;
    } catch (_) {
      return null;
    }
  }

  void logout() {
    currentUser = null;
  }
}
