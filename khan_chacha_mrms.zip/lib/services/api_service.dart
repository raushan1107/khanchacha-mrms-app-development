import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/maintenance_request.dart';
import '../models/user_account.dart';

class ApiService {
  ApiService._internal();

  static final ApiService _instance = ApiService._internal();

  factory ApiService() => _instance;

  // Choose the correct URL based on where Flutter is running:
  // Windows desktop (flutter run -d windows): 'http://localhost:3000/api'
  // Android emulator:                         'http://10.0.2.2:3000/api'
  // Real Android phone (same WiFi):           'http://192.168.x.x:3000/api'
  // After AWS deployment:                     'https://your-api.amazonaws.com/api'
  static const String _baseUrl = 'http://localhost:3000/api';

  // HTTP is stateless — no connection to open. Kept for parity with DatabaseService.
  Future<void> connect() async {}

  Future<UserAccount?> loginUser(String username, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/auth/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'username': username, 'password': password}),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        return UserAccount(
          id: data['id']?.toString() ?? '',
          name: data['name']?.toString() ?? '',
          username: data['username']?.toString() ?? '',
          password: '',
          role: data['role']?.toString() ?? 'staff',
          outletId: data['outletId']?.toString() ?? '',
          outletName: data['outletName']?.toString() ?? '',
          outletAddress: data['outletAddress']?.toString() ?? '',
        );
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  Future<List<MaintenanceRequest>> fetchAll() async {
    final response = await http.get(Uri.parse('$_baseUrl/requests'));
    if (response.statusCode >= 400) {
      throw Exception('API Error ${response.statusCode}: ${response.body}');
    }
    final list = jsonDecode(response.body) as List;
    return list
        .map((item) => MaintenanceRequest.fromJson(item as Map<String, dynamic>))
        .toList();
  }

  Future<List<MaintenanceRequest>> fetchByOutlet(String outletId) async {
    final response =
        await http.get(Uri.parse('$_baseUrl/requests?outlet_id=$outletId'));
    if (response.statusCode >= 400) {
      throw Exception('API Error ${response.statusCode}: ${response.body}');
    }
    final list = jsonDecode(response.body) as List;
    return list
        .map((item) => MaintenanceRequest.fromJson(item as Map<String, dynamic>))
        .toList();
  }

  Future<void> createRequest(MaintenanceRequest r) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/requests'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(r.toInsertMap()),
    );
    if (response.statusCode != 201) {
      throw Exception('Create failed: ${response.body}');
    }
  }

  Future<void> updateStatus(
      String id, String newStatus, String historyEntry) async {
    final response = await http.patch(
      Uri.parse('$_baseUrl/requests/$id/status'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'status': newStatus, 'history_entry': historyEntry}),
    );
    if (response.statusCode >= 400) {
      throw Exception('API Error ${response.statusCode}: ${response.body}');
    }
  }

  Future<void> updateRequest(MaintenanceRequest r) async {
    final response = await http.put(
      Uri.parse('$_baseUrl/requests/${r.id}'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(r.toInsertMap()),
    );
    if (response.statusCode >= 400) {
      throw Exception('API Error ${response.statusCode}: ${response.body}');
    }
  }

  Future<void> deleteRequest(String id) async {
    final response =
        await http.delete(Uri.parse('$_baseUrl/requests/$id'));
    if (response.statusCode != 200) {
      throw Exception('Delete failed: ${response.body}');
    }
  }

  Future<Map<String, int>> getStatusCounts({String? outletId}) async {
    final url = outletId != null
        ? '$_baseUrl/dashboard/counts?outlet_id=$outletId'
        : '$_baseUrl/dashboard/counts';
    final response = await http.get(Uri.parse(url));
    if (response.statusCode >= 400) {
      throw Exception('API Error ${response.statusCode}: ${response.body}');
    }
    final raw = jsonDecode(response.body) as Map<String, dynamic>;
    return raw.map((k, v) => MapEntry(k, (v as num?)?.toInt() ?? 0));
  }
}
