import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/maintenance_request.dart';
import '../models/user_account.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';

// ── Standalone screen (Scaffold + AppBar) ─────────────────────────────────────

class RequestFormScreen extends StatelessWidget {
  final UserAccount currentUser;
  final MaintenanceRequest? existingRequest;

  const RequestFormScreen({
    super.key,
    required this.currentUser,
    this.existingRequest,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: true,
        title: Text(existingRequest != null ? 'Edit Request' : 'New Request'),
      ),
      body: RequestFormContent(
        currentUser: currentUser,
        existingRequest: existingRequest,
        onDone: (r) => Navigator.of(context).pop(r),
      ),
    );
  }
}

// ── Embeddable form widget (no Scaffold) ──────────────────────────────────────

class RequestFormContent extends StatefulWidget {
  final UserAccount currentUser;
  final MaintenanceRequest? existingRequest;
  final void Function(MaintenanceRequest?) onDone;

  const RequestFormContent({
    super.key,
    required this.currentUser,
    this.existingRequest,
    required this.onDone,
  });

  @override
  State<RequestFormContent> createState() => _RequestFormContentState();
}

class _RequestFormContentState extends State<RequestFormContent>
    with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _productNameCtrl = TextEditingController();
  final _productIdCtrl = TextEditingController();
  final _outletAddressCtrl = TextEditingController();
  final _descriptionCtrl = TextEditingController();
  final _outletIdCtrl = TextEditingController();
  final _outletNameCtrl = TextEditingController();
  final _managerNameCtrl = TextEditingController();

  String? _selectedCategory;
  String _selectedStatus = 'Open';
  String? _selectedImagePath;

  late final AnimationController _pulseController;
  late final Animation<double> _pulseOpacity;

  bool get _isEditMode => widget.existingRequest != null;

  static const _categories = ['Electrical', 'AC', 'Kitchen'];
  static const _statusOptions = ['Open', 'Pending', 'Closed'];

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
    _pulseOpacity = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    if (_isEditMode) {
      final r = widget.existingRequest!;
      _productNameCtrl.text = r.productName;
      _productIdCtrl.text = r.productId;
      _outletAddressCtrl.text = r.outletAddress;
      _descriptionCtrl.text = r.description;
      _outletIdCtrl.text = r.outletId;
      _outletNameCtrl.text = r.outletName;
      _managerNameCtrl.text = r.managerName;
      _selectedCategory = r.category;
      _selectedStatus = r.status;
      _selectedImagePath = r.imagePath;
    } else {
      _outletIdCtrl.text = widget.currentUser.outletId;
      _outletNameCtrl.text = widget.currentUser.outletName;
      const addressMap = {
        'OUT-01': '25, Connaught Place, New Delhi – 110001',
        'OUT-02': '14, Central Market, Lajpat Nagar II, New Delhi – 110024',
      };
      _outletAddressCtrl.text = widget.currentUser.outletAddress.isNotEmpty
          ? widget.currentUser.outletAddress
          : (addressMap[widget.currentUser.outletId] ?? widget.currentUser.outletId);
      _managerNameCtrl.text = widget.currentUser.name;
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _productNameCtrl.dispose();
    _productIdCtrl.dispose();
    _outletAddressCtrl.dispose();
    _descriptionCtrl.dispose();
    _outletIdCtrl.dispose();
    _outletNameCtrl.dispose();
    _managerNameCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final xFile = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (xFile != null && mounted) {
      setState(() => _selectedImagePath = xFile.path);
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    if (_isEditMode) {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Confirm Update'),
          content: Text('Save changes to ${_productNameCtrl.text.trim()}?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel',
                  style: TextStyle(color: AppColors.textSecondary)),
            ),
            TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Save Changes',
                  style: TextStyle(color: AppColors.accentGold)),
            ),
          ],
        ),
      );
      if (!mounted || confirmed != true) return;
    }

    await _saveRequest();
  }

  Future<void> _saveRequest() async {
    final dateStr = DateTime.now().toString().split(' ')[0];

    if (_isEditMode) {
      final updated = widget.existingRequest!.copyWith(
        productName: _productNameCtrl.text.trim(),
        productId: _productIdCtrl.text.trim(),
        category: _selectedCategory,
        description: _descriptionCtrl.text.trim(),
        status: _selectedStatus,
        imagePath: _selectedImagePath,
      );
      try {
        await ApiService().updateRequest(updated);
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Saved'),
            backgroundColor: AppColors.statusClosed,
          ),
        );
        widget.onDone(updated);
      } catch (e) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
        );
      }
    } else {
      final newRequest = MaintenanceRequest(
        id: 'REQ-${DateTime.now().millisecondsSinceEpoch.toString().substring(8)}',
        productName: _productNameCtrl.text.trim(),
        productId: _productIdCtrl.text.trim(),
        category: _selectedCategory!,
        status: 'Open',
        requestDate: dateStr,
        description: _descriptionCtrl.text.trim(),
        raisedBy: widget.currentUser.id,
        managerName: '',
        outletId: _outletIdCtrl.text,
        outletName: _outletNameCtrl.text,
        outletAddress: _outletAddressCtrl.text,
        imagePath: _selectedImagePath,
        statusHistory: ['Open – $dateStr'],
      );
      try {
        await ApiService().createRequest(newRequest);
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Request submitted'),
            backgroundColor: AppColors.statusClosed,
          ),
        );
        widget.onDone(newRequest);
      } catch (e) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  InputDecoration _fieldDec(String label, {IconData? icon}) {
    return InputDecoration(
      labelText: label,
      prefixIcon: icon != null
          ? Icon(icon, color: AppColors.textSecondary)
          : null,
    );
  }

  InputDecoration _readonlyDec(String label, {IconData? icon}) {
    return InputDecoration(
      labelText: label,
      prefixIcon: icon != null
          ? Icon(icon, color: AppColors.textHint)
          : null,
      filled: true,
      fillColor: AppColors.bgPrimary,
      labelStyle: const TextStyle(color: AppColors.textHint),
    );
  }

  Widget _sectionLabel(String title) {
    return Padding(
      padding: const EdgeInsets.only(top: 20, bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: AppColors.accentAmber,
              letterSpacing: 1.2,
            ),
          ),
          const SizedBox(height: 6),
          const Divider(height: 1, color: AppColors.divider),
        ],
      ),
    );
  }

  Widget _buildImagePicker() {
    if (_selectedImagePath != null) {
      return CustomPaint(
        painter: _DashedBorderPainter(),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Stack(
            children: [
              Image.file(
                File(_selectedImagePath!),
                width: double.infinity,
                height: 180,
                fit: BoxFit.cover,
              ),
              Positioned(
                top: 8,
                right: 8,
                child: GestureDetector(
                  onTap: () => setState(() => _selectedImagePath = null),
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child:
                        const Icon(Icons.close, color: Colors.white, size: 18),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return GestureDetector(
      onTap: _pickImage,
      child: AnimatedBuilder(
        animation: _pulseOpacity,
        builder: (_, child) => Opacity(
          opacity: _pulseOpacity.value,
          child: child,
        ),
        child: CustomPaint(
          painter: _DashedBorderPainter(color: AppColors.border),
          child: const SizedBox(
            width: double.infinity,
            height: 110,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.camera_alt_outlined,
                    size: 36, color: AppColors.textHint),
                SizedBox(height: 8),
                Text(
                  'Tap to attach an image of the issue',
                  style:
                      TextStyle(color: AppColors.textSecondary, fontSize: 13),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatusField() {
    final editable = _isEditMode && widget.currentUser.role == 'manager';

    if (!editable) {
      return TextFormField(
        initialValue: _selectedStatus,
        readOnly: true,
        enabled: false,
        style: const TextStyle(color: AppColors.textHint),
        decoration: _readonlyDec(
          _isEditMode ? 'Status' : 'Status (auto-assigned)',
          icon: Icons.flag_outlined,
        ),
      );
    }

    return DropdownButtonFormField<String>(
      value: _selectedStatus,
      dropdownColor: AppColors.bgSurface,
      style: const TextStyle(color: AppColors.textPrimary),
      decoration: _fieldDec('Status', icon: Icons.flag_outlined),
      items: _statusOptions
          .map((s) => DropdownMenuItem(
                value: s,
                child:
                    Text(s, style: const TextStyle(color: AppColors.textPrimary)),
              ))
          .toList(),
      onChanged: (v) => setState(() => _selectedStatus = v!),
      validator: (v) => v == null ? 'Select a status' : null,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _sectionLabel('PRODUCT INFO'),

                  TextFormField(
                    controller: _productNameCtrl,
                    textCapitalization: TextCapitalization.words,
                    style: const TextStyle(color: AppColors.textPrimary),
                    decoration: _fieldDec('Product Name',
                        icon: Icons.inventory_2_outlined),
                    validator: (v) {
                      if (v == null || v.trim().isEmpty) {
                        return 'Product name is required';
                      }
                      if (v.trim().length < 3) {
                        return 'Must be at least 3 characters';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 12),

                  TextFormField(
                    controller: _productIdCtrl,
                    style: const TextStyle(color: AppColors.textPrimary),
                    decoration: _fieldDec('Product ID', icon: Icons.tag),
                    validator: (v) => (v == null || v.trim().isEmpty)
                        ? 'Product ID is required'
                        : null,
                  ),
                  const SizedBox(height: 12),

                  DropdownButtonFormField<String>(
                    value: _selectedCategory,
                    dropdownColor: AppColors.bgSurface,
                    style: const TextStyle(color: AppColors.textPrimary),
                    decoration:
                        _fieldDec('Category', icon: Icons.category_outlined),
                    hint: const Text('Select category',
                        style: TextStyle(color: AppColors.textHint)),
                    items: _categories
                        .map((c) => DropdownMenuItem(
                              value: c,
                              child: Text(c,
                                  style: const TextStyle(
                                      color: AppColors.textPrimary)),
                            ))
                        .toList(),
                    onChanged: (v) => setState(() => _selectedCategory = v),
                    validator: (v) => v == null ? 'Select a category' : null,
                  ),

                  _sectionLabel('OUTLET DETAILS'),

                  TextFormField(
                    controller: _outletIdCtrl,
                    readOnly: true,
                    style: const TextStyle(color: AppColors.textHint),
                    decoration:
                        _readonlyDec('Outlet ID', icon: Icons.store_outlined),
                  ),
                  const SizedBox(height: 12),

                  TextFormField(
                    controller: _outletNameCtrl,
                    readOnly: true,
                    style: const TextStyle(color: AppColors.textHint),
                    decoration: _readonlyDec('Outlet Name',
                        icon: Icons.storefront_outlined),
                  ),
                  const SizedBox(height: 12),

                  TextFormField(
                    controller: _managerNameCtrl,
                    readOnly: true,
                    style: const TextStyle(color: AppColors.textHint),
                    decoration: _readonlyDec('Manager Name',
                        icon: Icons.person_outline),
                  ),
                  const SizedBox(height: 12),

                  TextFormField(
                    controller: _outletAddressCtrl,
                    readOnly: true,
                    style: const TextStyle(color: AppColors.textHint),
                    decoration: _readonlyDec('Outlet Address',
                        icon: Icons.location_on_outlined),
                  ),

                  _sectionLabel('REQUEST DETAILS'),

                  TextFormField(
                    controller: _descriptionCtrl,
                    maxLines: 4,
                    style: const TextStyle(color: AppColors.textPrimary),
                    decoration: _fieldDec('Description')
                        .copyWith(alignLabelWithHint: true),
                    validator: (v) {
                      if (v == null || v.trim().isEmpty) {
                        return 'Description is required';
                      }
                      if (v.trim().length < 10) {
                        return 'Must be at least 10 characters';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 12),

                  _buildStatusField(),

                  _sectionLabel('ATTACHMENT'),

                  _buildImagePicker(),

                  const SizedBox(height: 8),
                ],
              ),
            ),
          ),
        ),

        Container(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
          decoration: BoxDecoration(
            color: AppColors.bgSurface,
            border: const Border(top: BorderSide(color: AppColors.border)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.2),
                blurRadius: 8,
                offset: const Offset(0, -2),
              ),
            ],
          ),
          child: SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: _submit,
              child:
                  Text(_isEditMode ? 'Update Request' : 'Submit Request'),
            ),
          ),
        ),
      ],
    );
  }
}

// ── Dashed border painter ──────────────────────────────────────────────────────

class _DashedBorderPainter extends CustomPainter {
  final Color color;

  const _DashedBorderPainter({this.color = AppColors.border});

  @override
  void paint(Canvas canvas, Size size) {
    const dashLen = 8.0;
    const gapLen = 5.0;

    final paint = Paint()
      ..color = color
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    final path = Path()
      ..addRRect(RRect.fromRectAndRadius(
        Rect.fromLTWH(0, 0, size.width, size.height),
        const Radius.circular(8),
      ));

    for (final metric in path.computeMetrics()) {
      double distance = 0;
      while (distance < metric.length) {
        final end = (distance + dashLen).clamp(0.0, metric.length);
        canvas.drawPath(metric.extractPath(distance, end), paint);
        distance += dashLen + gapLen;
      }
    }
  }

  @override
  bool shouldRepaint(_DashedBorderPainter old) => old.color != color;
}
