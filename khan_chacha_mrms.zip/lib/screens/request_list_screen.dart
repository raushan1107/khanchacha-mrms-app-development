import 'package:flutter/material.dart';
import '../models/maintenance_request.dart';
import '../models/user_account.dart';
import '../services/api_service.dart';
import '../services/navigation_service.dart';
import '../theme/app_theme.dart';
import 'detail_screen.dart';
import 'request_form_screen.dart';

// ── Standalone screen (Scaffold + AppBar + FAB) ───────────────────────────────

class RequestListScreen extends StatefulWidget {
  final UserAccount user;

  const RequestListScreen({super.key, required this.user});

  @override
  State<RequestListScreen> createState() => _RequestListScreenState();
}

class _RequestListScreenState extends State<RequestListScreen> {
  final _contentKey = GlobalKey<RequestListContentState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: true,
        title: const Text('Requests'),
        actions: [
          IconButton(
            icon: const Icon(Icons.sort),
            tooltip: 'Sort',
            onPressed: () => _contentKey.currentState?.openSortSheet(context),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.of(context)
            .push(NavigationService.slideFromBottom(
                RequestFormScreen(currentUser: widget.user)))
            .then((_) => _contentKey.currentState?.reload()),
        child: const Icon(Icons.add),
      ),
      body: RequestListContent(key: _contentKey, user: widget.user),
    );
  }
}

// ── Embeddable content widget (no Scaffold) ────────────────────────────────────

class RequestListContent extends StatefulWidget {
  final UserAccount user;

  const RequestListContent({super.key, required this.user});

  @override
  State<RequestListContent> createState() => RequestListContentState();
}

class RequestListContentState extends State<RequestListContent> {
  final _searchController = TextEditingController();
  String _searchQuery = '';
  String _statusFilter = 'All';
  String _categoryFilter = 'All';
  String _sortOrder = 'Newest First';

  List<MaintenanceRequest> _requests = [];
  bool _isLoading = true;

  static const _statuses = ['All', 'Open', 'Pending', 'Closed'];
  static const _categories = ['All', 'Electrical', 'AC', 'Kitchen'];

  @override
  void initState() {
    super.initState();
    _loadRequests();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadRequests() async {
    setState(() => _isLoading = true);
    try {
      final data = widget.user.role == 'manager'
          ? await ApiService().fetchAll()
          : await ApiService().fetchByOutlet(widget.user.outletId);
      setState(() {
        _requests = data;
        _isLoading = false;
      });
      debugPrint('=== REQUESTS LOADED: ${_requests.length} items ===');
      for (var r in _requests) {
        debugPrint('  ID:${r.id} | NAME:${r.productName} | CAT:${r.category} | STATUS:${r.status}');
      }
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to load requests: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> reload() => _loadRequests();

  String? _statusToData(String displayStatus) {
    return displayStatus == 'All' ? null : displayStatus;
  }

  int _countForStatus(String status) {
    if (status == 'All') return _requests.length;
    return _requests.where((r) => r.status == _statusToData(status)).length;
  }

  List<MaintenanceRequest> get _filtered {
    var list = List<MaintenanceRequest>.from(_requests);

    if (_searchQuery.isNotEmpty) {
      final q = _searchQuery.toLowerCase();
      list = list
          .where((r) =>
              r.productName.toLowerCase().contains(q) ||
              r.outletName.toLowerCase().contains(q))
          .toList();
    }

    if (_statusFilter != 'All') {
      list = list.where((r) => r.status == _statusToData(_statusFilter)).toList();
    }

    if (_categoryFilter != 'All') {
      list = list.where((r) => r.category == _categoryFilter).toList();
    }

    switch (_sortOrder) {
      case 'Newest First':
        list.sort((a, b) => b.requestDate.compareTo(a.requestDate));
        break;
      case 'Oldest First':
        list.sort((a, b) => a.requestDate.compareTo(b.requestDate));
        break;
      case 'By Outlet ID':
        list.sort((a, b) => a.outletId.compareTo(b.outletId));
        break;
    }

    return list;
  }

  Future<void> _onRefresh() async => _loadRequests();

  void openSortSheet(BuildContext ctx) {
    showModalBottomSheet<void>(
      context: ctx,
      builder: (sheetCtx) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 12, 16, 4),
              child: Text(
                'Sort By',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 15,
                  color: AppColors.textPrimary,
                ),
              ),
            ),
            const Divider(height: 1),
            ...['Newest First', 'Oldest First', 'By Outlet ID'].map(
              (option) => ListTile(
                title: Text(option,
                    style: const TextStyle(color: AppColors.textPrimary)),
                trailing: _sortOrder == option
                    ? const Icon(Icons.check_circle, color: AppColors.accentGold)
                    : null,
                onTap: () {
                  setState(() => _sortOrder = option);
                  Navigator.pop(sheetCtx);
                },
              ),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 4, 4),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _searchController,
              onChanged: (v) => setState(() => _searchQuery = v),
              style: const TextStyle(color: AppColors.textPrimary),
              decoration: InputDecoration(
                hintText: 'Search by product or outlet…',
                prefixIcon: const Icon(Icons.search, size: 20),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear, size: 18),
                        onPressed: () {
                          _searchController.clear();
                          setState(() => _searchQuery = '');
                        },
                      )
                    : null,
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(vertical: 10),
              ),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.sort, color: AppColors.textSecondary),
            tooltip: 'Sort',
            onPressed: () => openSortSheet(context),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusTabs() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(
        children: _statuses.map((s) {
          final isSelected = _statusFilter == s;
          final count = _countForStatus(s);
          Color chipColor = AppColors.accentGold;
          if (s == 'Open') chipColor = AppColors.statusOpen;
          if (s == 'Pending') chipColor = AppColors.statusPending;
          if (s == 'Closed') chipColor = AppColors.statusClosed;

          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: ChoiceChip(
              label: Text('$s ($count)'),
              selected: isSelected,
              onSelected: (_) => setState(() => _statusFilter = s),
              selectedColor: isSelected
                  ? (s == 'All' ? AppColors.accentGold : chipColor)
                      .withValues(alpha: 0.25)
                  : null,
              backgroundColor: AppColors.bgCard,
              labelStyle: TextStyle(
                color: isSelected ? chipColor : AppColors.textSecondary,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                fontSize: 12,
              ),
              side: BorderSide(
                color: isSelected ? chipColor : AppColors.border,
              ),
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildCategoryChips() {
    const categoryIcons = {
      'Electrical': Icons.bolt,
      'AC': Icons.ac_unit,
      'Kitchen': Icons.kitchen,
    };

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
      child: Row(
        children: _categories.map((c) {
          final isSelected = _categoryFilter == c;
          final icon = c != 'All' ? categoryIcons[c] : null;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: ChoiceChip(
              avatar: icon != null
                  ? Icon(icon,
                      size: 14,
                      color: isSelected
                          ? AppColors.accentGold
                          : AppColors.textHint)
                  : null,
              label: Text(c),
              selected: isSelected,
              onSelected: (_) => setState(() => _categoryFilter = c),
              selectedColor: AppColors.bgElevated,
              backgroundColor: AppColors.bgCard,
              labelStyle: TextStyle(
                color:
                    isSelected ? AppColors.accentGold : AppColors.textSecondary,
                fontSize: 12,
              ),
              side: BorderSide(
                color: isSelected ? AppColors.accentGold : AppColors.border,
              ),
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.inbox_outlined, size: 64, color: AppColors.textHint),
          const SizedBox(height: 12),
          const Text(
            'No requests found',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Try adjusting your filters or search query.',
            style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: AppColors.accentGold),
      );
    }

    final results = _filtered;

    return RefreshIndicator(
      onRefresh: _onRefresh,
      color: AppColors.accentGold,
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(child: _buildSearchBar()),
          SliverToBoxAdapter(child: _buildStatusTabs()),
          SliverToBoxAdapter(child: _buildCategoryChips()),
          const SliverToBoxAdapter(
              child: Divider(height: 1, color: AppColors.divider)),
          if (results.isEmpty)
            SliverFillRemaining(
              hasScrollBody: false,
              child: _buildEmptyState(),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.only(top: 8, bottom: 16),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (_, i) {
                    final req = results[i];
                    debugPrint('Card $i: productName="${req.productName}" | category="${req.category}" | status="${req.status}" | outletName="${req.outletName}" | date="${req.requestDate}"');

                    Color statusColor;
                    Color statusBg;
                    switch (req.status) {
                      case 'Open':
                        statusColor = const Color(0xFFE8A020);
                        statusBg = const Color(0xFF3A2800);
                        break;
                      case 'Pending':
                        statusColor = const Color(0xFF4A90D9);
                        statusBg = const Color(0xFF0A2040);
                        break;
                      case 'Closed':
                        statusColor = const Color(0xFF4CAF50);
                        statusBg = const Color(0xFF0A280A);
                        break;
                      default:
                        statusColor = const Color(0xFFE8A020);
                        statusBg = const Color(0xFF3A2800);
                    }

                    IconData catIcon;
                    switch (req.category) {
                      case 'Electrical':
                        catIcon = Icons.bolt;
                        break;
                      case 'AC':
                        catIcon = Icons.ac_unit;
                        break;
                      case 'Kitchen':
                        catIcon = Icons.kitchen;
                        break;
                      default:
                        catIcon = Icons.build;
                    }

                    final card = GestureDetector(
                      onTap: () => Navigator.of(context)
                          .push<MaintenanceRequest>(
                            NavigationService.slideFromRight(
                              DetailScreen(
                                  request: req, currentUser: widget.user),
                            ),
                          )
                          .then((_) => _loadRequests()),
                      child: Container(
                        margin: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 6),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: const Color(0xFF1C2B1C),
                          borderRadius: BorderRadius.circular(12),
                          border: Border(
                            left: BorderSide(color: statusColor, width: 4),
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 44,
                              height: 44,
                              decoration: BoxDecoration(
                                color: const Color(0xFF243024),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Icon(catIcon,
                                  color: const Color(0xFFD4A017), size: 22),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    req.productName.isNotEmpty
                                        ? req.productName
                                        : '(${req.id})',
                                    style: const TextStyle(
                                      color: Color(0xFFF5F0E8),
                                      fontSize: 15,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    '${req.category}  ·  ${req.outletName.isNotEmpty ? req.outletName : req.outletId}',
                                    style: const TextStyle(
                                      color: Color(0xFFB8C8B0),
                                      fontSize: 12,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    req.requestDate.isNotEmpty
                                        ? req.requestDate
                                        : '—',
                                    style: const TextStyle(
                                      color: Color(0xFF8A9E8A),
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 12),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: statusBg,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                req.status,
                                style: TextStyle(
                                  color: statusColor,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );

                    if (widget.user.role != 'manager') return card;
                    return Dismissible(
                      key: ValueKey(req.id),
                      direction: DismissDirection.endToStart,
                      background: Container(
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 20),
                        margin: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.red[800],
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.delete_outline,
                                color: Colors.white, size: 22),
                            SizedBox(height: 4),
                            Text('Delete',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 11)),
                          ],
                        ),
                      ),
                      confirmDismiss: (_) => showDialog<bool>(
                        context: context,
                        builder: (ctx) => AlertDialog(
                          title: const Text('Delete Request?'),
                          content: Text(
                            'Delete "${req.productName}"? This cannot be undone.',
                          ),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(ctx, false),
                              child: const Text('Cancel',
                                  style: TextStyle(
                                      color: AppColors.textSecondary)),
                            ),
                            TextButton(
                              onPressed: () => Navigator.pop(ctx, true),
                              child: const Text('Delete',
                                  style: TextStyle(color: Colors.red)),
                            ),
                          ],
                        ),
                      ),
                      onDismissed: (_) async {
                        setState(() =>
                            _requests.removeWhere((r) => r.id == req.id));
                        try {
                          await ApiService().deleteRequest(req.id);
                        } catch (e) {
                          await _loadRequests();
                          if (!context.mounted) return;
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('Delete failed: $e'),
                              backgroundColor: Colors.red,
                            ),
                          );
                        }
                      },
                      child: card,
                    );
                  },
                  childCount: results.length,
                ),
              ),
            ),
        ],
      ),
    );
  }
}
