import 'package:flutter/material.dart';
import '../models/maintenance_request.dart';
import '../models/user_account.dart';
import '../services/auth_service.dart';
import '../services/api_service.dart';
import '../services/navigation_service.dart';
import '../theme/app_theme.dart';
import 'detail_screen.dart';
import 'login_screen.dart';
import 'request_form_screen.dart';
import 'request_list_screen.dart';

class DashboardScreen extends StatefulWidget {
  final UserAccount user;

  const DashboardScreen({super.key, required this.user});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedIndex = 0;
  int _listVersion = 0;

  final List<bool> _cardVisible = [false, false, false];
  Map<String, int> _statusCounts = {};
  List<MaintenanceRequest> _recentRequests = [];
  bool _statsLoading = true;

  @override
  void initState() {
    super.initState();
    _loadDashboardData();
  }

  Future<void> _loadDashboardData() async {
    setState(() {
      _statsLoading = true;
      _cardVisible[0] = false;
      _cardVisible[1] = false;
      _cardVisible[2] = false;
    });
    try {
      final results = await Future.wait([
        ApiService().getStatusCounts(
            outletId:
                widget.user.role == 'staff' ? widget.user.outletId : null),
        widget.user.role == 'manager'
            ? ApiService().fetchAll()
            : ApiService().fetchByOutlet(widget.user.outletId),
      ]);
      setState(() {
        _statusCounts = results[0] as Map<String, int>;
        _recentRequests = results[1] as List<MaintenanceRequest>;
        _statsLoading = false;
      });
      _triggerCardAnimation();
    } catch (e) {
      setState(() => _statsLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to load dashboard: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _triggerCardAnimation() {
    for (int i = 0; i < 3; i++) {
      Future.delayed(Duration(milliseconds: i * 150), () {
        if (mounted) setState(() => _cardVisible[i] = true);
      });
    }
  }

  void _confirmLogout() {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Logout?'),
        content: const Text('Are you sure you want to sign out?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel',
                style: TextStyle(color: AppColors.textSecondary)),
          ),
          TextButton(
            onPressed: () {
              AuthService().logout();
              Navigator.of(context).pushAndRemoveUntil(
                NavigationService.fade(const LoginScreen()),
                (_) => false,
              );
            },
            child: const Text('Logout', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _openDetailScreen(MaintenanceRequest r) {
    Navigator.of(context)
        .push<MaintenanceRequest>(
          NavigationService.slideFromRight(
            DetailScreen(request: r, currentUser: widget.user),
          ),
        )
        .then((_) {
      if (mounted) _loadDashboardData();
    });
  }

  void _onNavSelect(int i) {
    if (i == 1 && _selectedIndex != 1) _listVersion++;
    if (i == 0 && _selectedIndex != 0) _loadDashboardData();
    setState(() => _selectedIndex = i);
  }

  // ── Navigation rail ────────────────────────────────────────────────────────

  Widget _buildRail() {
    return NavigationRail(
      extended: true,
      selectedIndex: _selectedIndex,
      onDestinationSelected: _onNavSelect,
      leading: Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Icon(Icons.restaurant,
            color: AppColors.accentGold, size: 32),
      ),
      trailing: Expanded(
        child: Align(
          alignment: Alignment.bottomCenter,
          child: Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: IconButton(
              icon: const Icon(Icons.logout_outlined),
              tooltip: 'Logout',
              color: AppColors.textSecondary,
              onPressed: _confirmLogout,
            ),
          ),
        ),
      ),
      destinations: const [
        NavigationRailDestination(
          icon: Icon(Icons.home_outlined),
          selectedIcon: Icon(Icons.home),
          label: Text('Home'),
        ),
        NavigationRailDestination(
          icon: Icon(Icons.list_alt_outlined),
          selectedIcon: Icon(Icons.list_alt),
          label: Text('Requests'),
        ),
        NavigationRailDestination(
          icon: Icon(Icons.add_circle_outline),
          selectedIcon: Icon(Icons.add_circle),
          label: Text('New Request'),
        ),
      ],
    );
  }

  // ── Content router ─────────────────────────────────────────────────────────

  Widget _buildContent() {
    switch (_selectedIndex) {
      case 0:
        return widget.user.role == 'manager'
            ? _buildManagerBody()
            : _buildStaffBody();
      case 1:
        return RequestListContent(
          key: ValueKey(_listVersion),
          user: widget.user,
        );
      case 2:
        return RequestFormContent(
          key: ValueKey(_listVersion),
          currentUser: widget.user,
          onDone: (result) {
            if (result != null) {
              _loadDashboardData();
              _listVersion++;
            }
            setState(() => _selectedIndex = 0);
          },
        );
      default:
        return const SizedBox.shrink();
    }
  }

  // ── Status cards row ───────────────────────────────────────────────────────

  Widget _buildStatusCards() {
    final openCount = _statusCounts['Open'] ?? 0;
    final pendingCount = _statusCounts['Pending'] ?? 0;
    final closedCount = _statusCounts['Closed'] ?? 0;

    if (_statsLoading) {
      return const SizedBox(
        height: 80,
        child: Center(
          child: CircularProgressIndicator(color: AppColors.accentGold),
        ),
      );
    }

    return Row(
      children: [
        Expanded(
          child: _AnimatedCard(
            visible: _cardVisible[0],
            child: _StatusCard(
              label: 'Open',
              count: openCount,
              statusColor: AppColors.statusOpen,
              bgColor: AppColors.statusBgOpen,
              icon: Icons.radio_button_unchecked,
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _AnimatedCard(
            visible: _cardVisible[1],
            child: _StatusCard(
              label: 'Pending',
              count: pendingCount,
              statusColor: AppColors.statusPending,
              bgColor: AppColors.statusBgPending,
              icon: Icons.schedule,
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _AnimatedCard(
            visible: _cardVisible[2],
            child: _StatusCard(
              label: 'Closed',
              count: closedCount,
              statusColor: AppColors.statusClosed,
              bgColor: AppColors.statusBgClosed,
              icon: Icons.check_circle_outline,
            ),
          ),
        ),
      ],
    );
  }

  // ── Manager body ───────────────────────────────────────────────────────────

  Widget _buildManagerBody() {
    final attentionItems = _recentRequests
        .where((r) => r.status == 'Open')
        .take(3)
        .toList();

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.location_on,
                  color: AppColors.accentGold, size: 18),
              const SizedBox(width: 6),
              const Text(
                'All Outlets',
                style: TextStyle(
                  color: AppColors.textSecondary,
                  fontSize: 13,
                ),
              ),
              const Spacer(),
              IconButton(
                icon: const Icon(Icons.refresh_rounded,
                    color: Color(0xFF8A9E8A), size: 20),
                tooltip: 'Refresh',
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
                onPressed: _loadDashboardData,
              ),
            ],
          ),
          const SizedBox(height: 16),
          _buildStatusCards(),
          const SizedBox(height: 24),
          const Text(
            'RECENT OPEN REQUESTS',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: AppColors.accentAmber,
              letterSpacing: 1.2,
            ),
          ),
          const Divider(height: 16),
          const SizedBox(height: 4),
          if (attentionItems.isEmpty)
            _EmptyState(message: 'No open requests right now.')
          else
            ...attentionItems.map(
              (r) => _AttentionTile(
                request: r,
                onUpdate: () => _openDetailScreen(r),
              ),
            ),
        ],
      ),
    );
  }

  // ── Staff body ─────────────────────────────────────────────────────────────

  Widget _buildStaffBody() {
    final recentRequests = _recentRequests.take(3).toList();

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.location_on,
                  color: AppColors.accentGold, size: 18),
              const SizedBox(width: 6),
              Text(
                widget.user.outletName,
                style: const TextStyle(
                  color: AppColors.textSecondary,
                  fontSize: 13,
                ),
              ),
              const Spacer(),
              IconButton(
                icon: const Icon(Icons.refresh_rounded,
                    color: Color(0xFF8A9E8A), size: 20),
                tooltip: 'Refresh',
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
                onPressed: _loadDashboardData,
              ),
            ],
          ),
          const SizedBox(height: 16),
          _buildStatusCards(),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton.icon(
              onPressed: () => _onNavSelect(2),
              icon: const Icon(Icons.add),
              label: const Text('Raise Maintenance Request'),
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'YOUR RECENT REQUESTS',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: AppColors.accentAmber,
              letterSpacing: 1.2,
            ),
          ),
          const Divider(height: 16),
          const SizedBox(height: 4),
          if (recentRequests.isEmpty)
            _EmptyState(message: 'No requests from your outlet yet.')
          else
            ...recentRequests.map((r) => _RequestTile(request: r)),
        ],
      ),
    );
  }

  // ── Build ──────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        actions: [
          if (_selectedIndex == 0)
            IconButton(
              icon: const Icon(Icons.refresh_rounded),
              tooltip: 'Refresh dashboard',
              onPressed: _loadDashboardData,
            ),
        ],
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Khan Chacha MRMS',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: AppColors.accentGold,
              ),
            ),
            Text(
              'Welcome, ${widget.user.name}',
              style: const TextStyle(
                fontSize: 13,
                color: AppColors.textSecondary,
                fontWeight: FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
      body: Row(
        children: [
          _buildRail(),
          const VerticalDivider(
              width: 1, thickness: 1, color: AppColors.border),
          Expanded(child: _buildContent()),
        ],
      ),
    );
  }
}

// ── Animated card wrapper ──────────────────────────────────────────────────────

class _AnimatedCard extends StatelessWidget {
  final bool visible;
  final Widget child;

  const _AnimatedCard({required this.visible, required this.child});

  @override
  Widget build(BuildContext context) {
    return AnimatedOpacity(
      opacity: visible ? 1.0 : 0.0,
      duration: const Duration(milliseconds: 300),
      child: AnimatedSlide(
        offset: visible ? Offset.zero : const Offset(0, 0.25),
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
        child: child,
      ),
    );
  }
}

// ── Status card ────────────────────────────────────────────────────────────────

class _StatusCard extends StatelessWidget {
  final String label;
  final int count;
  final Color statusColor;
  final Color bgColor;
  final IconData icon;

  const _StatusCard({
    required this.label,
    required this.count,
    required this.statusColor,
    required this.bgColor,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border(
          left: BorderSide(color: statusColor, width: 4),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: statusColor, size: 18),
          const SizedBox(height: 6),
          Text(
            '$count',
            style: TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.bold,
              color: statusColor,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: const TextStyle(
              fontSize: 11,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}

// ── Attention tile ─────────────────────────────────────────────────────────────

class _AttentionTile extends StatelessWidget {
  final MaintenanceRequest request;
  final VoidCallback onUpdate;

  const _AttentionTile({required this.request, required this.onUpdate});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  request.productName,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  request.outletName,
                  style: const TextStyle(
                      color: AppColors.textSecondary, fontSize: 12),
                ),
                const SizedBox(height: 1),
                Text(
                  request.requestDate,
                  style: const TextStyle(
                      color: AppColors.textSecondary, fontSize: 11),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          ElevatedButton(
            onPressed: onUpdate,
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              minimumSize: Size.zero,
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
              textStyle:
                  const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
            ),
            child: const Text('View'),
          ),
        ],
      ),
    );
  }
}

// ── Request tile ───────────────────────────────────────────────────────────────

class _RequestTile extends StatelessWidget {
  final MaintenanceRequest request;

  const _RequestTile({required this.request});

  Color get _statusColor {
    switch (request.status) {
      case 'Open':
        return AppColors.statusOpen;
      case 'Pending':
        return AppColors.statusPending;
      case 'Closed':
        return AppColors.statusClosed;
      default:
        return AppColors.textHint;
    }
  }

  Color get _statusBg {
    switch (request.status) {
      case 'Open':
        return AppColors.statusBgOpen;
      case 'Pending':
        return AppColors.statusBgPending;
      case 'Closed':
        return AppColors.statusBgClosed;
      default:
        return AppColors.bgElevated;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  request.productName,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  '${request.category} · ${request.requestDate}',
                  style: const TextStyle(
                      color: AppColors.textSecondary, fontSize: 12),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: _statusBg,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              request.status,
              style: TextStyle(
                color: _statusColor,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final String message;

  const _EmptyState({required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.inbox_outlined,
                size: 64, color: AppColors.textHint),
            const SizedBox(height: 12),
            Text(
              message,
              style: const TextStyle(
                  color: AppColors.textSecondary, fontSize: 14),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
