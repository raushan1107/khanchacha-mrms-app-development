import 'dart:io';
import 'package:flutter/material.dart';
import '../models/maintenance_request.dart';
import '../models/user_account.dart';
import '../services/api_service.dart';
import '../services/navigation_service.dart';
import '../theme/app_theme.dart';
import 'request_form_screen.dart';

class DetailScreen extends StatefulWidget {
  final MaintenanceRequest request;
  final UserAccount currentUser;

  const DetailScreen({
    super.key,
    required this.request,
    required this.currentUser,
  });

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  late MaintenanceRequest _request;

  @override
  void initState() {
    super.initState();
    _request = widget.request;
  }

  // ── Colour / label helpers ─────────────────────────────────────────────────

  Color _statusColor(String status) {
    switch (status) {
      case 'Open':
        return AppColors.statusOpen;
      case 'Pending':
        return AppColors.statusPending;
      case 'Closed':
        return AppColors.statusClosed;
      default:
        return AppColors.textHint;
    }
  }

  Color _statusBg(String status) {
    switch (status) {
      case 'Open':
        return AppColors.statusBgOpen;
      case 'Pending':
        return AppColors.statusBgPending;
      case 'Closed':
        return AppColors.statusBgClosed;
      default:
        return AppColors.bgElevated;
    }
  }

  IconData _statusIcon(String status) {
    switch (status) {
      case 'Open':
        return Icons.radio_button_unchecked;
      case 'Pending':
        return Icons.schedule;
      case 'Closed':
        return Icons.check_circle;
      default:
        return Icons.help_outline;
    }
  }

  IconData _categoryIcon(String category) {
    switch (category) {
      case 'Electrical':
        return Icons.bolt;
      case 'AC':
        return Icons.ac_unit;
      case 'Kitchen':
        return Icons.kitchen;
      default:
        return Icons.build_outlined;
    }
  }

  List<Color> _categoryGradient(String category) {
    switch (category) {
      case 'Electrical':
        return [const Color(0xFF142414), const Color(0xFF1A2E1A)];
      case 'AC':
        return [const Color(0xFF122012), const Color(0xFF182818)];
      case 'Kitchen':
        return [const Color(0xFF1E1A0A), const Color(0xFF261E0C)];
      default:
        return [AppColors.bgSurface, AppColors.bgCard];
    }
  }

  // ── Update status ──────────────────────────────────────────────────────────

  void _openStatusSheet() {
    const options = ['Open', 'Pending', 'Closed'];
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 12, 16, 4),
              child: Text(
                'Update Status',
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textPrimary,
                ),
              ),
            ),
            const Divider(height: 1),
            ...options.map((label) {
              final isCurrent = _request.status == label;
              return ListTile(
                leading: Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    color: _statusColor(label),
                    shape: BoxShape.circle,
                  ),
                ),
                title: Text(label, style: const TextStyle(color: AppColors.textPrimary)),
                trailing: isCurrent
                    ? const Icon(Icons.check_circle, color: AppColors.accentGold)
                    : null,
                enabled: !isCurrent,
                onTap: () {
                  Navigator.pop(ctx);
                  _applyStatusUpdate(label);
                },
              );
            }),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Future<void> _applyStatusUpdate(String newStatus) async {
    final oldStatus = _request.status;
    final historyEntry =
        '{"from":"$oldStatus","to":"$newStatus","at":"${DateTime.now().toIso8601String()}"}';

    try {
      await ApiService().updateStatus(_request.id, newStatus, historyEntry);
      if (!mounted) return;
      setState(() {
        _request = _request.copyWith(
          status: newStatus,
          statusHistory: [..._request.statusHistory, historyEntry],
        );
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Status updated to $newStatus'),
          backgroundColor: AppColors.statusClosed,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Update failed: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  // ── Edit ───────────────────────────────────────────────────────────────────

  void _onEditTap() {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Edit Request?'),
        content: Text(
          'You are about to edit ${_request.id}. This will open the form '
          'with the current details pre-filled.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel',
                style: TextStyle(color: AppColors.textSecondary)),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              final updated = await Navigator.of(context)
                  .push<MaintenanceRequest>(
                NavigationService.slideFromBottom(
                  RequestFormScreen(
                    currentUser: widget.currentUser,
                    existingRequest: _request,
                  ),
                ),
              );
              if (updated != null && mounted) {
                setState(() => _request = updated);
              }
            },
            child: const Text('Continue Editing',
                style: TextStyle(color: AppColors.accentGold)),
          ),
        ],
      ),
    );
  }

  // ── Delete ─────────────────────────────────────────────────────────────────

  void _onDeleteTap() {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Request?'),
        content: Text(
          'Are you sure you want to permanently delete '
          '${_request.productName} (${_request.id})? This cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel',
                style: TextStyle(color: AppColors.textSecondary)),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              try {
                await ApiService().deleteRequest(_request.id);
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Request deleted'),
                    backgroundColor: AppColors.statusClosed,
                  ),
                );
                Navigator.of(context).pop();
              } catch (e) {
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Delete failed: $e'),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  // ── Status banner ──────────────────────────────────────────────────────────

  Widget _buildStatusBanner() {
    final statusClr = _statusColor(_request.status);
    final statusBgClr = _statusBg(_request.status);
    final gradColors = _categoryGradient(_request.category);
    final catIcon = _categoryIcon(_request.category);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 28, 20, 24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: gradColors,
        ),
        border: Border(
          bottom: BorderSide(
            color: statusClr.withValues(alpha: 0.4),
            width: 2,
          ),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(catIcon, color: AppColors.accentGold, size: 40),
          const SizedBox(height: 10),
          Text(
            _request.productName,
            style: const TextStyle(
              color: AppColors.textPrimary,
              fontSize: 22,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 10),
          Hero(
            tag: 'status-badge-${_request.id}',
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: statusBgClr,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: statusClr.withValues(alpha: 0.5)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(_statusIcon(_request.status),
                        color: statusClr, size: 14),
                    const SizedBox(width: 6),
                    Text(
                      _request.status,
                      style: TextStyle(
                        color: statusClr,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Info rows ──────────────────────────────────────────────────────────────

  Widget _infoRow(IconData icon, String label, String value) {
    final isEmpty = value.trim().isEmpty;
    final displayValue = isEmpty ? '—' : value;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: AppColors.accentGold, size: 18),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: const TextStyle(
                        color: AppColors.textHint,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      displayValue,
                      style: TextStyle(
                        color: isEmpty
                            ? const Color(0xFF6A7A6A)
                            : AppColors.textPrimary,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const Divider(height: 1, color: AppColors.divider),
      ],
    );
  }

  Widget _buildDetailsCard() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'REQUEST DETAILS',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: AppColors.accentAmber,
              letterSpacing: 1.2,
            ),
          ),
          const SizedBox(height: 8),
          _infoRow(Icons.tag, 'REQUEST ID', _request.id),
          _infoRow(Icons.inventory_2_outlined, 'PRODUCT NAME', _request.productName),
          _infoRow(Icons.numbers, 'PRODUCT ID', _request.productId),
          _infoRow(Icons.category_outlined, 'CATEGORY', _request.category),
          _infoRow(Icons.calendar_today_outlined, 'DATE', _request.requestDate),
          _infoRow(Icons.store_outlined, 'OUTLET ID', _request.outletId),
          _infoRow(Icons.storefront_outlined, 'OUTLET NAME', _request.outletName),
          _infoRow(Icons.location_on_outlined, 'ADDRESS', _request.outletAddress),
          _infoRow(Icons.person_outline, 'OUTLET MANAGER', _request.managerName),
          _infoRow(Icons.account_circle_outlined, 'RAISED BY', _request.raisedBy),
          _infoRow(Icons.description_outlined, 'DESCRIPTION', _request.description),
        ],
      ),
    );
  }

  // ── Image section ──────────────────────────────────────────────────────────

  Widget _buildImageSection() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'ATTACHED IMAGE',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: AppColors.accentAmber,
              letterSpacing: 1.2,
            ),
          ),
          const SizedBox(height: 12),
          if (_request.imagePath != null) ...[
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.file(
                File(_request.imagePath!),
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
          ] else
            Container(
              width: double.infinity,
              height: 100,
              decoration: BoxDecoration(
                color: AppColors.bgElevated,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.border),
              ),
              child: const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.image_not_supported_outlined,
                      color: AppColors.textHint, size: 32),
                  SizedBox(height: 6),
                  Text(
                    'No image attached',
                    style: TextStyle(color: AppColors.textHint, fontSize: 13),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  // ── Status history ─────────────────────────────────────────────────────────

  Widget _buildHistorySection() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'STATUS HISTORY',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: AppColors.accentAmber,
              letterSpacing: 1.2,
            ),
          ),
          const SizedBox(height: 12),
          if (_request.statusHistory.isEmpty)
            const Text(
              'No changes yet.',
              style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
            )
          else
            ...List.generate(_request.statusHistory.length, (i) {
              final entry = _request.statusHistory[i];
              final isLast = i == _request.statusHistory.length - 1;
              return IntrinsicHeight(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 18,
                      child: Column(
                        children: [
                          Container(
                            width: 10,
                            height: 10,
                            margin: const EdgeInsets.only(top: 4),
                            decoration: BoxDecoration(
                              color: isLast
                                  ? AppColors.accentGold
                                  : AppColors.textHint,
                              shape: BoxShape.circle,
                            ),
                          ),
                          if (!isLast)
                            Expanded(
                              child: Container(
                                width: 1,
                                margin: const EdgeInsets.symmetric(vertical: 3),
                                color: AppColors.divider,
                              ),
                            ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.only(bottom: isLast ? 0 : 14),
                        child: Text(
                          entry,
                          style: TextStyle(
                            fontSize: 13,
                            color: isLast
                                ? AppColors.textPrimary
                                : AppColors.textSecondary,
                            fontWeight: isLast ? FontWeight.w500 : FontWeight.normal,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            }),
        ],
      ),
    );
  }

  // ── Action bar ─────────────────────────────────────────────────────────────

  Widget _buildActionBar() {
    final isManager = widget.currentUser.role == 'manager';
    final canEdit = isManager ||
        (widget.currentUser.role == 'staff' &&
            _request.status == 'Open' &&
            _request.outletId == widget.currentUser.outletId);

    if (!isManager && !canEdit) return const SizedBox.shrink();

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
      decoration: BoxDecoration(
        color: AppColors.bgSurface,
        border: const Border(top: BorderSide(color: AppColors.border)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.2),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Row(
        children: [
          if (isManager) ...[
            Expanded(
              child: SizedBox(
                height: 44,
                child: ElevatedButton.icon(
                  onPressed: _openStatusSheet,
                  icon: const Icon(Icons.update, size: 16),
                  label: const Text('Update Status'),
                ),
              ),
            ),
            const SizedBox(width: 10),
          ],
          if (canEdit) ...[
            Expanded(
              child: SizedBox(
                height: 44,
                child: ElevatedButton.icon(
                  onPressed: _onEditTap,
                  icon: const Icon(Icons.edit_outlined, size: 16),
                  label: const Text('Edit'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.bgElevated,
                    foregroundColor: AppColors.textPrimary,
                    side: const BorderSide(color: AppColors.border),
                  ),
                ),
              ),
            ),
          ],
          if (isManager) ...[
            const SizedBox(width: 10),
            Expanded(
              child: SizedBox(
                height: 44,
                child: OutlinedButton.icon(
                  onPressed: _onDeleteTap,
                  icon: const Icon(Icons.delete_outline, size: 16),
                  label: const Text('Delete'),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Colors.red),
                    foregroundColor: Colors.red,
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ── Build ──────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_request.productName),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new),
          onPressed: () => Navigator.of(context).pop(_request),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildStatusBanner(),
                  _buildDetailsCard(),
                  _buildImageSection(),
                  _buildHistorySection(),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
          _buildActionBar(),
        ],
      ),
    );
  }
}
