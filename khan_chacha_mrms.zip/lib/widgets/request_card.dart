import 'package:flutter/material.dart';
import '../models/maintenance_request.dart';
import '../models/user_account.dart';
import '../screens/detail_screen.dart';
import '../services/navigation_service.dart';
import '../theme/app_theme.dart';

class RequestCard extends StatelessWidget {
  final MaintenanceRequest request;
  final UserAccount currentUser;
  final void Function(MaintenanceRequest?)? onReturn;

  const RequestCard({
    super.key,
    required this.request,
    required this.currentUser,
    this.onReturn,
  });

  void _navigateToDetail(BuildContext context) {
    Navigator.of(context)
        .push<MaintenanceRequest>(NavigationService.slideFromRight(
          DetailScreen(request: request, currentUser: currentUser),
        ))
        .then((result) => onReturn?.call(result));
  }

  IconData get _categoryIcon {
    switch (request.category) {
      case 'Electrical':
        return Icons.bolt;
      case 'AC':
        return Icons.ac_unit;
      case 'Kitchen':
        return Icons.kitchen;
      default:
        return Icons.build_outlined;
    }
  }

  Color get _statusColor {
    switch (request.status) {
      case 'Open':
        return const Color(0xFFE8A020);
      case 'Pending':
        return const Color(0xFF4A90D9);
      case 'Closed':
        return const Color(0xFF4CAF50);
      default:
        return const Color(0xFF8A9E8A);
    }
  }

  Color get _statusBg {
    switch (request.status) {
      case 'Open':
        return AppColors.statusBgOpen;
      case 'Pending':
        return AppColors.statusBgPending;
      case 'Closed':
        return AppColors.statusBgClosed;
      default:
        return AppColors.bgElevated;
    }
  }

  String _formatDate(String raw) {
    try {
      final dt = DateTime.parse(raw);
      const months = [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
      ];
      return '${dt.day} ${months[dt.month - 1]} ${dt.year}';
    } catch (_) {
      return raw;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border(
          left: BorderSide(color: _statusColor, width: 3),
          top: const BorderSide(color: AppColors.border, width: 0.5),
          right: const BorderSide(color: AppColors.border, width: 0.5),
          bottom: const BorderSide(color: AppColors.border, width: 0.5),
        ),
      ),
      child: InkWell(
        onTap: () => _navigateToDetail(context),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Category icon
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: AppColors.bgElevated,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(_categoryIcon, color: AppColors.accentGold, size: 20),
              ),
              const SizedBox(width: 12),

              // Middle content
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      request.productName.isNotEmpty
                          ? request.productName
                          : request.id,
                      style: const TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 15,
                        color: Color(0xFFF5F0E8),
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      '${request.category} · ${request.outletName}',
                      style: const TextStyle(
                        color: Color(0xFFB8C8B0),
                        fontSize: 12,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      _formatDate(request.requestDate),
                      style: const TextStyle(
                        color: Color(0xFF8A9E8A),
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),

              // Right side: status chip + chevron
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Hero(
                    tag: 'status-badge-${request.id}',
                    child: Material(
                      type: MaterialType.transparency,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: _statusBg,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          request.status,
                          style: TextStyle(
                            color: _statusColor,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Icon(Icons.chevron_right,
                      color: AppColors.textHint, size: 18),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
