class UserAccount {
  final String id;
  final String name;
  final String username;
  final String password;
  final String role; // 'manager' or 'staff'
  final String outletId;
  final String outletName;
  final String outletAddress;

  const UserAccount({
    required this.id,
    required this.name,
    required this.username,
    required this.password,
    required this.role,
    required this.outletId,
    required this.outletName,
    this.outletAddress = '',
  });
}
