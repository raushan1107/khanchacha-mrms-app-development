import 'dart:convert';

class MaintenanceRequest {
  final String id;
  final String productName;
  final String productId;
  final String category;
  final String status;
  final String requestDate;
  final String description;
  final String raisedBy;
  final String managerName;
  final String outletId;
  final String outletName;
  final String outletAddress;
  final String? imagePath;
  final List<String> statusHistory;

  const MaintenanceRequest({
    required this.id,
    required this.productName,
    required this.productId,
    required this.category,
    required this.status,
    required this.requestDate,
    required this.description,
    required this.raisedBy,
    required this.managerName,
    required this.outletId,
    required this.outletName,
    required this.outletAddress,
    this.imagePath,
    this.statusHistory = const [],
  });

  MaintenanceRequest copyWith({
    String? id,
    String? productName,
    String? productId,
    String? category,
    String? status,
    String? requestDate,
    String? description,
    String? raisedBy,
    String? managerName,
    String? outletId,
    String? outletName,
    String? outletAddress,
    String? imagePath,
    List<String>? statusHistory,
  }) {
    return MaintenanceRequest(
      id: id ?? this.id,
      productName: productName ?? this.productName,
      productId: productId ?? this.productId,
      category: category ?? this.category,
      status: status ?? this.status,
      requestDate: requestDate ?? this.requestDate,
      description: description ?? this.description,
      raisedBy: raisedBy ?? this.raisedBy,
      managerName: managerName ?? this.managerName,
      outletId: outletId ?? this.outletId,
      outletName: outletName ?? this.outletName,
      outletAddress: outletAddress ?? this.outletAddress,
      imagePath: imagePath ?? this.imagePath,
      statusHistory: statusHistory ?? this.statusHistory,
    );
  }

  factory MaintenanceRequest.fromJson(Map<String, dynamic> json) {
    return MaintenanceRequest(
      id: json['id']?.toString() ?? '',
      productName: json['product_name']?.toString() ?? '',
      productId: json['product_id']?.toString() ?? '',
      category: json['category']?.toString() ?? '',
      status: json['status']?.toString() ?? '',
      requestDate: json['request_date']?.toString() ?? '',
      description: json['description']?.toString() ?? '',
      raisedBy: json['raised_by']?.toString() ?? '',
      managerName: json['manager_name']?.toString() ?? '',
      outletId: json['outlet_id']?.toString() ?? '',
      outletName: json['outlet_name']?.toString() ?? '',
      outletAddress: json['outlet_address']?.toString() ?? '',
      imagePath: json['image_path']?.toString(),
      statusHistory: (json['status_history'] as List?)
              ?.map((e) => e.toString())
              .toList() ??
          [],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'product_name': productName,
      'product_id': productId,
      'category': category,
      'status': status,
      'request_date': requestDate,
      'description': description,
      'raised_by': raisedBy,
      'manager_name': managerName,
      'outlet_id': outletId,
      'outlet_name': outletName,
      'outlet_address': outletAddress,
      'image_path': imagePath,
      'status_history': statusHistory,
    };
  }

  factory MaintenanceRequest.fromRow(Map row) {
    return MaintenanceRequest(
      id: row['id'] as String,
      productName: row['product_name'] as String,
      productId: row['product_id'] as String,
      category: row['category'] as String,
      status: row['status'] as String,
      requestDate: row['request_date'] as String,
      description: row['description'] as String,
      raisedBy: row['raised_by']?.toString() ?? '',
      managerName: row['manager_name']?.toString() ?? '',
      outletId: row['outlet_id'] as String,
      outletName: row['outlet_name'] as String,
      outletAddress: row['outlet_address'] as String,
      imagePath: row['image_path'] as String?,
      statusHistory: (row['status_history'] as List)
          .map((e) => e.toString())
          .toList(),
    );
  }

  Map<String, dynamic> toInsertMap() {
    return {
      'id': id,
      'product_name': productName,
      'product_id': productId,
      'category': category,
      'status': status,
      'request_date': requestDate,
      'description': description,
      'image_path': imagePath,
      'outlet_id': outletId,
      'raised_by': raisedBy,
      'status_history': jsonEncode(statusHistory),
    };
  }
}
